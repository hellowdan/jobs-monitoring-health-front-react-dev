import axios from 'axios';

const JOB_API_BASE_URL = "https://jobs-monitoring-health-baqe-jobs-dashboards.6923.rh-us-east-1.openshiftapps.com/api";

class JobService {

    getJobs(){
        return axios.get(JOB_API_BASE_URL + '/jobs');
    }

    addJob(job){
        return axios.post(JOB_API_BASE_URL + '/add-job', job);
    }

    getJobById(jobId){
        return axios.get(JOB_API_BASE_URL + '/job/' + jobId);
    }

}

export default new JobService()